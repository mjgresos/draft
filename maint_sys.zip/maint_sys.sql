-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 16, 2020 at 08:01 AM
-- Server version: 10.1.39-MariaDB
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `maint_sys`
--
CREATE DATABASE IF NOT EXISTS `maint_sys` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `maint_sys`;

-- --------------------------------------------------------

--
-- Table structure for table `area_check`
--

CREATE TABLE `area_check` (
  `area_check_id` int(2) NOT NULL,
  `area_desc` varchar(500) NOT NULL,
  `prop_type_id` int(19) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `area_check`
--

INSERT INTO `area_check` (`area_check_id`, `area_desc`, `prop_type_id`) VALUES
(0, 'No Area Needed', 2),
(1, 'Filters, Refrigerant, Oil Motors, Thermostat, Drain Channels, Electric Terminals', 1),
(2, 'Hardware', 1),
(3, 'Software', 1),
(4, 'Electrical', 3),
(5, 'Plumbing', 3),
(6, 'Carpentry', 3),
(7, 'Ground Maintenance', 3);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `emp_no` int(2) NOT NULL,
  `emp_id` varchar(11) NOT NULL,
  `emp_fname` varchar(50) NOT NULL,
  `emp_lname` varchar(50) NOT NULL,
  `emp_mname` varchar(50) NOT NULL,
  `emp_gender` varchar(1) NOT NULL,
  `office_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`emp_no`, `emp_id`, `emp_fname`, `emp_lname`, `emp_mname`, `emp_gender`, `office_id`) VALUES
(1, '2015-12345', 'Mayo', 'Lape', 'Francisco', 'F', 1),
(2, '2015-54321', 'Solomon', 'Castillo', 'Fernandez', 'M', 4),
(3, '2015-20917', 'Carl Stephen', 'Caya', 'Gorit', 'M', 3),
(4, '2015-93812', 'Matt Jacob', 'Rulona', 'Castro', 'M', 3);

-- --------------------------------------------------------

--
-- Table structure for table `gen_sched`
--

CREATE TABLE `gen_sched` (
  `gen_sched_id` int(10) NOT NULL,
  `prop_group_id` int(10) NOT NULL,
  `emp_no` int(10) NOT NULL,
  `gen_date` date NOT NULL,
  `area_check_id` int(10) NOT NULL,
  `office_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gen_sched`
--

INSERT INTO `gen_sched` (`gen_sched_id`, `prop_group_id`, `emp_no`, `gen_date`, `area_check_id`, `office_id`) VALUES
(1, 1, 1, '2018-12-30', 1, 1),
(2, 3, 3, '2018-08-17', 3, 1),
(3, 3, 1, '2018-09-22', 3, 1),
(4, 1, 4, '2018-09-30', 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `maintenance`
--

CREATE TABLE `maintenance` (
  `maint_id` int(19) NOT NULL,
  `prop_id` int(19) NOT NULL,
  `plan_date` int(19) NOT NULL,
  `needs` int(2) NOT NULL,
  `maint_status` int(2) NOT NULL,
  `maint_type_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `maint_type`
--

CREATE TABLE `maint_type` (
  `maint_type_id` int(19) NOT NULL,
  `maint_type_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `office`
--

CREATE TABLE `office` (
  `office_id` int(11) NOT NULL,
  `office_acro` varchar(50) NOT NULL,
  `office_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `office`
--

INSERT INTO `office` (`office_id`, `office_acro`, `office_name`) VALUES
(1, 'GSU', 'General Services Unit'),
(2, 'IC', 'Institute of Computing'),
(3, 'CE', 'College Of Engineering'),
(4, 'CEd', 'College of Education'),
(8, 'SAEc', 'School of Applied Economics'),
(9, 'CAS', 'College of Arts and Sciences'),
(10, 'OSAS', 'OSAS'),
(11, 'CT', 'College of Technology');

-- --------------------------------------------------------

--
-- Table structure for table `pre_maint`
--

CREATE TABLE `pre_maint` (
  `pm_no` int(10) NOT NULL,
  `prop_group_id` int(19) NOT NULL,
  `area_check_id` int(2) NOT NULL,
  `plan_jan` int(2) NOT NULL,
  `plan_feb` int(2) NOT NULL,
  `plan_mar` int(2) NOT NULL,
  `plan_apr` int(2) NOT NULL,
  `plan_may` int(2) NOT NULL,
  `plan_jun` int(2) NOT NULL,
  `plan_jul` int(2) NOT NULL,
  `plan_aug` int(2) NOT NULL,
  `plan_sep` int(2) NOT NULL,
  `plan_oct` int(2) NOT NULL,
  `plan_nov` int(2) NOT NULL,
  `plan_dec` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pre_maint`
--

INSERT INTO `pre_maint` (`pm_no`, `prop_group_id`, `area_check_id`, `plan_jan`, `plan_feb`, `plan_mar`, `plan_apr`, `plan_may`, `plan_jun`, `plan_jul`, `plan_aug`, `plan_sep`, `plan_oct`, `plan_nov`, `plan_dec`) VALUES
(1, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(3, 5, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(5, 4, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(6, 4, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `property`
--

CREATE TABLE `property` (
  `prop_id` int(3) NOT NULL,
  `prop_name` varchar(50) NOT NULL,
  `office_id` int(11) NOT NULL,
  `emp_no` int(19) NOT NULL,
  `prop_no` varchar(50) NOT NULL COMMENT 'Building Type',
  `mod_name` varchar(50) NOT NULL,
  `prop_ser` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `prop_needs` int(3) NOT NULL,
  `prop_group_id` int(19) NOT NULL,
  `date_upd` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `property`
--

INSERT INTO `property` (`prop_id`, `prop_name`, `office_id`, `emp_no`, `prop_no`, `mod_name`, `prop_ser`, `status`, `prop_needs`, `prop_group_id`, `date_upd`) VALUES
(8, 'one one one', 10, 3, '111', 'one 1 one', '1 one 1', 'Serviceable', 1, 0, '2018-07-13'),
(9, 'Walis', 2, 1, '15613', '12423', '2412', 'Serviceable', 1, 0, '2018-07-14'),
(12, 'AAAAAAA', 3, 1, 'AAAAAA', '12423', '357657', 'Not Serviceable', 2, 2, '2019-11-13'),
(13, 'Broom', 1, 1, '15613', '2563', '', 'Not Serviceable', 1, 0, '2018-07-18'),
(15, 'college', 2, 2, '546282', '12423', '357657', 'Serviceable', 0, 4, '2018-07-18'),
(19, 'Broom', 3, 1, '15613', '2563', '357657', 'Not Serviceable', 0, 2, '2018-07-18'),
(20, 'Broom', 10, 4, '15613', '0000000000000000000000', '2412', 'Serviceable', 1, 2, '2019-11-13'),
(21, 'Stick', 8, 1, '546282', '2563', '6666', 'Not Serviceable', 1, 1, '2018-07-19'),
(23, 'Broom', 2, 1, '15613', '432', '2412', 'Serviceable', 0, 4, '2018-07-19'),
(25, 'CAR', 8, 2, 'CAR', 'CAR', '9187329', 'Serviceable', 3, 0, '2018-07-19'),
(26, 'Broom', 2, 1, '15613', '12423', '357657', 'Not Serviceable', 1, 1, '2018-07-23'),
(29, 'dako', 1, 2, 'building ', '19023', '01238', 'Serviceable', 0, 4, '2018-07-24'),
(31, 'HP Computer', 1, 1, '1293', 'alskdha', 'o129309', 'Serviceable', 1, 1, '2018-08-14'),
(32, 'jkashdk', 1, 2, '91703', '013nl', '109731', 'Not Serviceable', 1, 1, '2018-08-14'),
(33, '0kalsjd', 1, 1, '2130', '012ijnl', '9012n', 'Not Serviceable', 1, 1, '2018-08-14'),
(34, '019327091097', 1, 1, '91832n', '0973', '09370', 'Not Serviceable', 1, 1, '2018-08-14'),
(35, 'AAAAAAAA', 1, 3, '123012', '91732', '', 'Not Serviceable', 1, 1, '2018-08-14'),
(36, 'volkswagen', 1, 1, '321903', '1', '', 'Not Serviceable', 1, 0, '2018-08-14'),
(37, 'lkasjd', 1, 1, '13279109', '13279109kasjd', '129837', 'Not Serviceable', 2, 3, '2018-09-23'),
(38, '66666666', 1, 2, '66666', '666666', '66666666', 'Serviceable', 0, 2, '2018-09-24'),
(39, '33333', 3, 4, '333', '3333', '33333', 'Not Serviceable', 0, 2, '2018-09-24'),
(40, 'Little boi', 10, 4, '09090909', '66666', '0950', 'Serviceable', 3, 3, '2019-10-08'),
(41, 'CAYA LAPTOP', 1, 3, '09000393939', 'ASUS 3', '09199932328', 'Serviceable', 3, 1, '2019-10-09'),
(42, 'zero one', 9, 4, '01', 'zero one 01', '0101', 'Serviceable', 2, 3, '2019-11-13'),
(43, 'BRUH', 1, 4, 'BRUH', 'BRUH', 'BRUH', 'Not Serviceable', 0, 2, '2019-12-24'),
(44, 'Honda', 2, 3, '43', 'YTS-86879', '09865868', 'Not Serviceable', 1, 0, '2020-06-19');

-- --------------------------------------------------------

--
-- Table structure for table `prop_group`
--

CREATE TABLE `prop_group` (
  `prop_group_id` int(19) NOT NULL,
  `prop_group_name` varchar(50) NOT NULL,
  `prop_type_id` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prop_group`
--

INSERT INTO `prop_group` (`prop_group_id`, `prop_group_name`, `prop_type_id`) VALUES
(0, 'Vehicle', 2),
(1, 'Computer', 1),
(2, 'College Of Engineering', 3),
(3, 'Printer', 1),
(4, 'College of Arts and Science', 3),
(5, 'Aircondition', 1);

-- --------------------------------------------------------

--
-- Table structure for table `prop_type`
--

CREATE TABLE `prop_type` (
  `prop_type_id` int(19) NOT NULL,
  `prop_type_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prop_type`
--

INSERT INTO `prop_type` (`prop_type_id`, `prop_type_name`) VALUES
(1, 'Equipment'),
(2, 'Vehicle'),
(3, 'Building');

-- --------------------------------------------------------

--
-- Table structure for table `spef_sched`
--

CREATE TABLE `spef_sched` (
  `sched_id` int(3) NOT NULL,
  `prop_id` int(3) NOT NULL,
  `emp_no` int(3) NOT NULL,
  `planned_date` date NOT NULL,
  `area_check_id` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `spef_sched`
--

INSERT INTO `spef_sched` (`sched_id`, `prop_id`, `emp_no`, `planned_date`, `area_check_id`) VALUES
(2, 8, 1, '2018-07-29', 0),
(3, 13, 2, '2018-07-30', 0),
(5, 29, 1, '2018-12-31', 6),
(7, 8, 2, '2018-09-07', 0),
(8, 8, 1, '2018-12-31', 0),
(9, 36, 1, '2018-12-31', 0),
(10, 12, 2, '2018-09-30', 3),
(11, 38, 2, '2018-09-30', 6);

-- --------------------------------------------------------

--
-- Table structure for table `workorder`
--

CREATE TABLE `workorder` (
  `wo_no` int(10) NOT NULL,
  `wo_con` varchar(500) NOT NULL,
  `wo_ver` varchar(500) NOT NULL,
  `wo_acc` varchar(500) NOT NULL,
  `office_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `area_check`
--
ALTER TABLE `area_check`
  ADD PRIMARY KEY (`area_check_id`),
  ADD KEY `prop_type_id` (`prop_type_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`emp_no`),
  ADD KEY `office_id` (`office_id`);

--
-- Indexes for table `gen_sched`
--
ALTER TABLE `gen_sched`
  ADD PRIMARY KEY (`gen_sched_id`),
  ADD KEY `prop_group_id` (`prop_group_id`),
  ADD KEY `area_check_id` (`area_check_id`),
  ADD KEY `emp_id` (`emp_no`),
  ADD KEY `office_id` (`office_id`);

--
-- Indexes for table `maintenance`
--
ALTER TABLE `maintenance`
  ADD PRIMARY KEY (`maint_id`),
  ADD KEY `prop_ID` (`prop_id`),
  ADD KEY `maint_type_ID` (`maint_type_id`);

--
-- Indexes for table `maint_type`
--
ALTER TABLE `maint_type`
  ADD PRIMARY KEY (`maint_type_id`);

--
-- Indexes for table `office`
--
ALTER TABLE `office`
  ADD PRIMARY KEY (`office_id`);

--
-- Indexes for table `pre_maint`
--
ALTER TABLE `pre_maint`
  ADD PRIMARY KEY (`pm_no`),
  ADD KEY `area_check_id` (`area_check_id`),
  ADD KEY `prop_group_id` (`prop_group_id`);

--
-- Indexes for table `property`
--
ALTER TABLE `property`
  ADD PRIMARY KEY (`prop_id`),
  ADD KEY `office_id` (`office_id`),
  ADD KEY `prop_group_id` (`prop_group_id`),
  ADD KEY `emp_no` (`emp_no`);

--
-- Indexes for table `prop_group`
--
ALTER TABLE `prop_group`
  ADD PRIMARY KEY (`prop_group_id`),
  ADD KEY `prop_type_ID` (`prop_type_id`);

--
-- Indexes for table `prop_type`
--
ALTER TABLE `prop_type`
  ADD PRIMARY KEY (`prop_type_id`);

--
-- Indexes for table `spef_sched`
--
ALTER TABLE `spef_sched`
  ADD PRIMARY KEY (`sched_id`),
  ADD KEY `prop_id` (`prop_id`),
  ADD KEY `emp_no` (`emp_no`),
  ADD KEY `area_check_id` (`area_check_id`);

--
-- Indexes for table `workorder`
--
ALTER TABLE `workorder`
  ADD PRIMARY KEY (`wo_no`),
  ADD KEY `office_id` (`office_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `area_check`
--
ALTER TABLE `area_check`
  MODIFY `area_check_id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `emp_no` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `office`
--
ALTER TABLE `office`
  MODIFY `office_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `pre_maint`
--
ALTER TABLE `pre_maint`
  MODIFY `pm_no` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `property`
--
ALTER TABLE `property`
  MODIFY `prop_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `prop_group`
--
ALTER TABLE `prop_group`
  MODIFY `prop_group_id` int(19) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `prop_type`
--
ALTER TABLE `prop_type`
  MODIFY `prop_type_id` int(19) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `area_check`
--
ALTER TABLE `area_check`
  ADD CONSTRAINT `area_check_ibfk_1` FOREIGN KEY (`prop_type_id`) REFERENCES `prop_type` (`prop_type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`office_id`) REFERENCES `office` (`office_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pre_maint`
--
ALTER TABLE `pre_maint`
  ADD CONSTRAINT `pre_maint_ibfk_1` FOREIGN KEY (`area_check_id`) REFERENCES `area_check` (`area_check_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pre_maint_ibfk_2` FOREIGN KEY (`prop_group_id`) REFERENCES `prop_group` (`prop_group_id`);

--
-- Constraints for table `property`
--
ALTER TABLE `property`
  ADD CONSTRAINT `property_ibfk_1` FOREIGN KEY (`office_id`) REFERENCES `office` (`office_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `property_ibfk_2` FOREIGN KEY (`prop_group_id`) REFERENCES `prop_group` (`prop_group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `property_ibfk_3` FOREIGN KEY (`emp_no`) REFERENCES `employee` (`emp_no`);

--
-- Constraints for table `prop_group`
--
ALTER TABLE `prop_group`
  ADD CONSTRAINT `prop_group_ibfk_1` FOREIGN KEY (`prop_type_id`) REFERENCES `prop_type` (`prop_type_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
